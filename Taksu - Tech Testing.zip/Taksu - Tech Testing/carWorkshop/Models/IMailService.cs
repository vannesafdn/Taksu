using System.Threading.Tasks;
using carWorkshop;

namespace carWorkshop{
    public interface IMailService
    {
        Task SendEmail(MailRequest mailRequest);
    }
}
