using System.Net.Mail;
using MimeKit;
using System.Threading.Tasks;
using MailKit.Security;
using Microsoft.Extensions.Options;

namespace carWorkshop
{
    public class MailService : IMailService
{
    private readonly MailSettings _mailSettings;

        public MailService()
        {
        }
        public MailService(IOptions<MailSettings> mailSettings)
        {
         _mailSettings = mailSettings.Value;
        }
        public void SendEmail(MailRequest mailRequest)
        {
            var email = new MimeMessage();
            email.Sender = MailboxAddress.Parse(_mailSettings.Mail);
            email.To.Add(MailboxAddress.Parse(mailRequest.ToEmail));
            email.Subject = mailRequest.Subject;
            //email.Body = mailRequest.Body;
            var builder = new BodyBuilder();
            builder.HtmlBody = mailRequest.Body;
            email.Body = builder.ToMessageBody();
            using var smtp = new SmtpClient();
            //smtp.SendMailAsync(_mailSettings.Host, _mailSettings.Port, SecureSocketOptions.StartTls);
            smtp.Host = _mailSettings.Host;
            smtp.Port = _mailSettings.Port;
            smtp.TargetName = _mailSettings.Mail;
            //smtp.Credentials = _mailSettings.Password;
            //smtp.DeliveryMethod(_mailSettings.Mail , _mailSettings.Password);
            //await smtp.SendAsync(_mailSettings.Mail);
            //smtp.SendAsyncCancel(true);
        }

        Task IMailService.SendEmail(MailRequest mailRequest)
        {
            throw new System.NotImplementedException();
        }
    }
}