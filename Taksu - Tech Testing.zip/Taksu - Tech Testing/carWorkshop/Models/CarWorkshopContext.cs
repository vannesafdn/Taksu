using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MySQL.Data.EntityFrameworkCore.Extensions;

namespace carWorkshop.Models
{
    public class CarWorkshopContext : DbContext
    {
        public static string ConnectionString { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySQL(ConnectionString);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Service>(entity =>
            {
                entity.Property(e => e.serviceid).HasColumnName("idService");
                entity.Property(e => e.servicename).HasColumnName("serviceName");
                entity.Property(e => e.serviceprice).HasColumnName("servicePrice");
            });
        }
        public virtual DbSet<Service> Services { get; set; }
    }
}