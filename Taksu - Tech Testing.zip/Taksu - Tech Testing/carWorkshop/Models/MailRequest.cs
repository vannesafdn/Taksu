using System.Net.Mail;
using MimeKit;
using System;

namespace carWorkshop
{
    public class MailRequest
    {
        public string ToEmail { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
    }
}
