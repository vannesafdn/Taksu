using System;

namespace carWorkshop.Models
{
    public class Mechanic{
        public int mechanicid { get; set; }
        public string mechanicname { get; set; }
        public string mechanicpassword { get; set; }
        public string mechanicemail { get; set; }
    }
}