using System;

namespace carWorkshop.Models
{
    public class Customer{
        public int customerid { get; set; }
        public string customername { get; set; }
        public string customerpassword { get; set; }
        public string customeremail { get; set; }
        public string customeraddress { get; set; }
        public string carid { get; set; }
        public string carlicense { get; set; }
    }
}