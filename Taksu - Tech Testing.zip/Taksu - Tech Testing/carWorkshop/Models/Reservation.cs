using System;

namespace carWorkshop.Models
{
    public class Reservation{
        public int serviceid { get; set; }
        public string servicename { get; set; }
        public double serviceprice { get; set; }
    }
}