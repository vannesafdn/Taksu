﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using carWorkshop.Models;
using MySql.Data.MySqlClient;

namespace carWorkshop.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class WorkshopController : ControllerBase
    {
        [HttpGet]
        public ActionResult<Customer> getCustomer()
        {
            IList<Customer> items = new List<Customer>();

            MySqlConnection conn = new MySqlConnection{
                ConnectionString = Startup.ConnectionString
            };
            conn.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM customer c LEFT JOIN log_user lu ON c.email=lu.username",conn);

            MySqlDataReader dataReader =cmd.ExecuteReader();
            while (dataReader.Read()){
                Customer item = new Customer();
                item.customeremail= Convert.ToString(dataReader["email"]);
                item.customername= Convert.ToString(dataReader["name"]);
                item.customerpassword= Convert.ToString(dataReader["password"]);

                items.Add(item);
            }
            dataReader.Close();
            conn.Close();

            return Ok(items);
        }
        
        [HttpGet]
        public ActionResult<Mechanic> getMechanic()
        {
            IList<Mechanic> items = new List<Mechanic>();

            MySqlConnection conn = new MySqlConnection{
                ConnectionString = Startup.ConnectionString
            };
            conn.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM mechanic m LEFT JOIN log_user lu  ON m.mechanicEmail=lu.username;",conn);
            MySqlDataReader dataReader =cmd.ExecuteReader();
            while (dataReader.Read()){
                Mechanic item = new Mechanic();
                item.mechanicemail= Convert.ToString(dataReader["mechanicEmail"]);
                item.mechanicname= Convert.ToString(dataReader["mechanicName"]);
                item.mechanicpassword= Convert.ToString(dataReader["password"]);
                items.Add(item);
            }
            dataReader.Close();
            conn.Close();

            return Ok(items);
        }

        [HttpGet]
        public ActionResult<Service> getService()
        {
            IList<Service> items = new List<Service>();

            MySqlConnection conn = new MySqlConnection{
                ConnectionString = Startup.ConnectionString
            };
            conn.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM service;",conn);
            MySqlDataReader dataReader =cmd.ExecuteReader();
            while (dataReader.Read()){
                Service item = new Service();
                item.servicename= Convert.ToString(dataReader["serviceName"]);
                item.serviceprice= Convert.ToDouble(dataReader["servicePrice"]);
                items.Add(item);
            }
            dataReader.Close();
            conn.Close();

            return Ok(items);
        }

        [HttpGet]
        public ActionResult<Customer> getAllCar(int id)
        {
            IList<Customer> items = new List<Customer>();

            MySqlConnection conn = new MySqlConnection{
                ConnectionString = Startup.ConnectionString
            };
            conn.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT * FROM customer cs LEFT JOIN car cr ON cs.idCustomer=cr.idCustomer;",conn);
            MySqlDataReader dataReader =cmd.ExecuteReader();
            while (dataReader.Read()){
                Customer item = new Customer();
                item.customeraddress= Convert.ToString(dataReader["address"]);
                item.customername= Convert.ToString(dataReader["name"]);
                item.customeremail= Convert.ToString(dataReader["email"]);
                item.carlicense= Convert.ToString(dataReader["licensePlate"]);
                item.customerid= Convert.ToInt32(dataReader["idCustomer"]);
                item.carid= Convert.ToString(dataReader["idCar"]);
                items.Add(item);
            }
            dataReader.Close();
            conn.Close();

            return Ok(items);
        }

        [HttpGet("{id}")]
        public ActionResult<Customer> getCar(int id)
        {
            IList<Customer> items = new List<Customer>();

            MySqlConnection conn = new MySqlConnection{
                ConnectionString = Startup.ConnectionString
            };
            conn.Open();

            MySqlCommand cmd = new MySqlCommand("SELECT cs.idCustomer, cs.`name`, cs.address, cs.email, cr.licensePlate, cr.idCar FROM customer cs LEFT JOIN car cr ON cs.idCustomer=cr.idCustomer WHERE cr.idCar=@id;",conn);
            MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("id", id);
            MySqlDataReader dataReader =cmd.ExecuteReader();
            while (dataReader.Read()){
                Customer item = new Customer();
                item.customeraddress= Convert.ToString(dataReader["address"]);
                item.customername= Convert.ToString(dataReader["name"]);
                item.customeremail= Convert.ToString(dataReader["email"]);
                item.carlicense= Convert.ToString(dataReader["licensePlate"]);
                item.customerid= Convert.ToInt32(dataReader["idCustomer"]);
                item.carid= Convert.ToString(dataReader["idCar"]);

                items.Add(item);
            }
            dataReader.Close();
            conn.Close();

            return Ok(items);
        }
        
        [HttpPost]
        public ActionResult addService([FromBody]Service srv) 
        {
            //IList <Service> items = new List<Service>();

            MySqlConnection conn = new MySqlConnection{
                ConnectionString = Startup.ConnectionString
            };
            conn.Open();

            MySqlCommand cmd = new MySqlCommand("INSERT INTO service (serviceName,servicePrice) VALUES(@serviceName,@servicePrice);",conn);
            MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("serviceName", srv.servicename);
            mySqlParameter = cmd.Parameters.AddWithValue("servicePrice", srv.serviceprice);
            MySqlDataReader dataReader =cmd.ExecuteReader();
            conn.Close();
            return Ok();
        }

        private readonly IMailService mailService;
        public WorkshopController(IMailService mailService)
        {
            this.mailService = mailService;
        }
        [HttpPost]
        public async Task<IActionResult> SendMail([FromForm]MailRequest request)
        {
            try
            {
                await mailService.SendEmail(request);
                return Ok();
            }
            catch (Exception)
            {
                throw;
            }    
        }

        [HttpDelete("{id}")]
        public ActionResult deleteService(int id) 
        {
            MySqlConnection conn = new MySqlConnection{
                ConnectionString = Startup.ConnectionString
            };
            conn.Open();

            MySqlCommand cmd = new MySqlCommand("DELETE FROM service WHERE idService = @id;", conn);
            MySqlParameter mySqlParameter = cmd.Parameters.AddWithValue("id",id);
            MySqlDataReader dataReader =cmd.ExecuteReader();
            conn.Close();
            return Ok();
        }
    }
}
