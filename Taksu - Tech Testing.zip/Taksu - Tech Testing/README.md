### **Cara Menjalankan API Reservation dan Service**

1. setelah file terdownload, buka file taksuAPI pada aplikasi teks editor anda (Visual Studio Code)
2. lalu jalankan program dengan memilih star debuging pada menu debug.
![image](https://user-images.githubusercontent.com/38001183/124387972-c33e8d00-dd0a-11eb-918a-679255984df2.png)
3. jika anda otomatis di arahkan ke browser maka program telah berhasil dijalankan.
4. setelah itu buka aplikasi testing API (posman)
5. lalu pilih import pada menu file, dan pilih file carWorkshop.postman_collection.curl
6. anda dapat melakukan testing terhadap url yang ada.
7. lakukan hal yang sama untuk file taksuAPI - Service


### **Entity Relationship Diagram - Car Workshop System**
[https://cloud.smartdraw.com/share.aspx/?pubDocShare=21D2CC60FC959FB101374752B5D62C4C4A0](url)


### **State Machine Diagram**
[SMD.vpp://diagram/WklSVl6GAqBYrwWK](url)

