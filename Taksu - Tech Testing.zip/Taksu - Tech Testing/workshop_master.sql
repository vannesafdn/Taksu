/*
 Navicat Premium Data Transfer

 Source Server         : LOCAL-MYSQL
 Source Server Type    : MySQL
 Source Server Version : 100137
 Source Host           : 127.0.0.1:3306
 Source Schema         : workshop_master

 Target Server Type    : MySQL
 Target Server Version : 100137
 File Encoding         : 65001

 Date: 05/07/2021 23:10:18
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `idCar` int(11) NOT NULL AUTO_INCREMENT,
  `licensePlate` varchar(30) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `idCustomer` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`idCar`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (1, 'B1238CD', 1);
INSERT INTO `car` VALUES (2, 'F5517FP', 2);
INSERT INTO `car` VALUES (3, 'B8356RT', 3);

-- ----------------------------
-- Table structure for complaint
-- ----------------------------
DROP TABLE IF EXISTS `complaint`;
CREATE TABLE `complaint`  (
  `idComplaint` int(11) NOT NULL,
  `idService` int(11) NULL DEFAULT NULL,
  `idMechanic` int(11) NULL DEFAULT NULL,
  `idCustomer` int(11) NULL DEFAULT NULL,
  `complain` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `idOrder` int(11) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of complaint
-- ----------------------------
INSERT INTO `complaint` VALUES (1, 3, 2, 2, 'the battery looks like it\'s been used', 1);

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer`  (
  `idCustomer` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idCustomer`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES (1, 'Syefi A', 'Tangerang Selatan', 'syefi@gmail.com');
INSERT INTO `customer` VALUES (2, 'Vannesa F', 'Bogor', 'domoniq10@gmail.com');
INSERT INTO `customer` VALUES (3, 'Farhan', 'Jakarta Selatan', 'farhan.f@gmail.com');

-- ----------------------------
-- Table structure for invoice
-- ----------------------------
DROP TABLE IF EXISTS `invoice`;
CREATE TABLE `invoice`  (
  `idInvoice` int(11) NOT NULL AUTO_INCREMENT,
  `idOrder` int(11) NULL DEFAULT NULL,
  `idCustomer` int(11) NULL DEFAULT NULL,
  `total_priceService` double(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`idInvoice`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of invoice
-- ----------------------------
INSERT INTO `invoice` VALUES (1, 1, 2, 80000.00);

-- ----------------------------
-- Table structure for log_user
-- ----------------------------
DROP TABLE IF EXISTS `log_user`;
CREATE TABLE `log_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of log_user
-- ----------------------------
INSERT INTO `log_user` VALUES (1, 'syefi@gmail.com', 'sy3f1', 'customer');
INSERT INTO `log_user` VALUES (2, 'domoniq10@gmail.com', 'vfdn', 'customer');
INSERT INTO `log_user` VALUES (3, 'farhan.f@gmail.com', 'f4rh4n', 'customer');
INSERT INTO `log_user` VALUES (4, 'john@gmail.com', 'j0hn', 'mechanic');
INSERT INTO `log_user` VALUES (5, 'stephen@gmail.com', 'st0567', 'mechanic');
INSERT INTO `log_user` VALUES (6, 'samuel@gmai.com', 'samy765', 'mechanic');

-- ----------------------------
-- Table structure for mechanic
-- ----------------------------
DROP TABLE IF EXISTS `mechanic`;
CREATE TABLE `mechanic`  (
  `idMechanic` int(11) NOT NULL AUTO_INCREMENT,
  `mechanicName` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `mechanicEmail` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`idMechanic`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of mechanic
-- ----------------------------
INSERT INTO `mechanic` VALUES (1, 'John', 'john@gmail.com');
INSERT INTO `mechanic` VALUES (2, 'Stephen', 'stephen@gmail.com');
INSERT INTO `mechanic` VALUES (3, 'Samuel', 'samuel@gmai.com');

-- ----------------------------
-- Table structure for order
-- ----------------------------
DROP TABLE IF EXISTS `order`;
CREATE TABLE `order`  (
  `idOrder` int(11) NOT NULL,
  `idService` int(11) NULL DEFAULT NULL,
  `idCar` int(11) NULL DEFAULT NULL,
  `servicePrice` double(11, 2) NULL DEFAULT NULL,
  `idMechanic` int(11) NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of order
-- ----------------------------
INSERT INTO `order` VALUES (1, 3, 2, 30000.00, 2, NULL);
INSERT INTO `order` VALUES (1, 1, 2, 50000.00, 1, NULL);

-- ----------------------------
-- Table structure for service
-- ----------------------------
DROP TABLE IF EXISTS `service`;
CREATE TABLE `service`  (
  `idService` int(11) NOT NULL AUTO_INCREMENT,
  `serviceName` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `servicePrice` double(10, 2) NULL DEFAULT NULL,
  PRIMARY KEY (`idService`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of service
-- ----------------------------
INSERT INTO `service` VALUES (1, 'Change tyres', 50000.00);
INSERT INTO `service` VALUES (2, 'Fix dents', 150000.00);
INSERT INTO `service` VALUES (3, 'Change battery', 30000.00);

SET FOREIGN_KEY_CHECKS = 1;
